/*    */ package me.pepperbell.anycapes.data;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.GsonBuilder;
/*    */ import java.io.File;
/*    */ import java.io.FileReader;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import me.pepperbell.anycapes.AnyCapes;
/*    */ 
/*    */ 
/*    */ public class Config
/*    */ {
/* 16 */   private static final Gson GSON = (new GsonBuilder())
/* 17 */     .setPrettyPrinting()
/* 18 */     .create();
/*    */   
/*    */   private File file;
/*    */   private Options options;
/*    */   
/*    */   public Config(File file) {
/* 24 */     this.file = file;
/*    */   }
/*    */   
/*    */   public Options getOptions() {
/* 28 */     return this.options;
/*    */   }
/*    */   
/*    */   public void load() {
/* 32 */     if (this.file.exists()) { 
/* 33 */       try { FileReader reader = new FileReader(this.file); 
/* 34 */         try { this.options = (Options)GSON.fromJson(reader, Options.class);
/* 35 */           reader.close(); } catch (Throwable throwable) { try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException e)
/* 36 */       { AnyCapes.LOGGER.error("Error loading config", e); }
/*    */        }
/*    */     else
/* 39 */     { this.options = new Options();
/* 40 */       save(); }
/*    */   
/*    */   }
/*    */   public void save() {
/*    */     
/* 45 */     try { FileWriter writer = new FileWriter(this.file); 
/* 46 */       try { writer.write(GSON.toJson(this.options));
/* 47 */         writer.close(); } catch (Throwable throwable) { try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException e)
/* 48 */     { AnyCapes.LOGGER.error("Error saving config", e); }
/*    */   
/*    */   }
/*    */   
/*    */   public static class Options {
/* 53 */     public static final Options DEFAULT = new Options();
/*    */     
/* 55 */     public List<String> capeUrls = Arrays.asList(new String[] { "http://capes.corruptedmc.xyz/{username}.png", "{mojang}", "http://s.optifine.net/capes/{username}.png" });
/*    */     public boolean useCaching = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kelly\Desktop\anycapes-1.0.1.jar!\me\pepperbell\anycapes\data\Config.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */