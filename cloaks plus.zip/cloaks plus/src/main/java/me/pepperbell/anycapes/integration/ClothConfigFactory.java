/*    */ package me.pepperbell.anycapes.integration;
/*    */ import io.github.prospector.modmenu.api.ConfigScreenFactory;
/*    */ import java.util.List;
/*    */ import me.pepperbell.anycapes.data.Config;
/*    */ import me.pepperbell.anycapes.util.ParsingUtil;
/*    */ import me.shedaniel.clothconfig2.api.AbstractConfigListEntry;
/*    */ import me.shedaniel.clothconfig2.api.ConfigBuilder;
/*    */ import me.shedaniel.clothconfig2.api.ConfigCategory;
/*    */ import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
/*    */ import me.shedaniel.clothconfig2.gui.entries.StringListListEntry;
/*    */ import net.minecraft.class_2477;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_2588;
/*    */ import net.minecraft.class_437;
/*    */ 
/*    */ public class ClothConfigFactory implements ConfigScreenFactory<class_437> {
/*    */   public ClothConfigFactory(Config config) {
/* 18 */     this.config = config;
/*    */   }
/*    */ 
/*    */   
/*    */   private Config config;
/*    */ 
/*    */   
/*    */   public class_437 create(class_437 parent) {
/* 26 */     ConfigBuilder builder = ConfigBuilder.create().setParentScreen(parent).setTitle((class_2561)new class_2588("anycapes.configuration.title")).setSavingRunnable(() -> this.config.save());
/*    */ 
/*    */     
/* 29 */     ConfigEntryBuilder entryBuilder = builder.entryBuilder();
/*    */     
/* 31 */     ConfigCategory general = builder.getOrCreateCategory((class_2561)new class_2588("anycapes.category.general"));
/* 32 */     general.addEntry((AbstractConfigListEntry)entryBuilder.startStrList((class_2561)new class_2588("anycapes.options.cape_urls"), (this.config.getOptions()).capeUrls)
/* 33 */         .setSaveConsumer(value -> (this.config.getOptions()).capeUrls = value)
/*    */ 
/*    */         
/* 36 */         .setTooltip(ParsingUtil.parseNewlines("anycapes.options.cape_urls.tooltip"))
/* 39 */         .setCreateNewInstance(entry -> new StringListListEntry.StringListCell(class_2477.method_10517().method_4679("anycapes.options.cape_urls.new_url"), entry))
/*    */ 
/*    */         
/* 42 */         .setDefaultValue(Config.Options.DEFAULT.capeUrls)
/* 43 */         .setExpanded(true)
/* 44 */         .setInsertInFront(false)
/* 45 */         .build());
/* 46 */     general.addEntry((AbstractConfigListEntry)entryBuilder.startBooleanToggle((class_2561)new class_2588("anycapes.options.use_caching"), (this.config.getOptions()).useCaching)
/* 47 */         .setSaveConsumer(value -> (this.config.getOptions()).useCaching = value.booleanValue())
/*    */ 
/*    */         
/* 50 */         .setTooltip(ParsingUtil.parseNewlines("anycapes.options.use_caching.tooltip"))
/* 51 */         .setDefaultValue(Config.Options.DEFAULT.useCaching)
/* 52 */         .build());
/*    */     
/* 54 */     return builder.build();
/*    */   }
/*    */ }


/* Location:              C:\Users\Kelly\Desktop\anycapes-1.0.1.jar!\me\pepperbell\anycapes\integration\ClothConfigFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */