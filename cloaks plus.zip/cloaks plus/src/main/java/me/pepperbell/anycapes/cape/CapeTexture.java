/*    */ package me.pepperbell.anycapes.cape;
/*    */ 
/*    */ import net.minecraft.class_1011;
/*    */ import net.minecraft.class_1043;
/*    */ 
/*    */ public class CapeTexture extends class_1043 {
/*    */   private boolean hasElytra = true;
/*    */   
/*    */   public CapeTexture(class_1011 image) {
/* 10 */     super(image);
/*    */   }
/*    */   
/*    */   public CapeTexture(class_1011 image, boolean hasElytra) {
/* 14 */     super(image);
/* 15 */     this.hasElytra = hasElytra;
/*    */   }
/*    */   
/*    */   public boolean hasElytra() {
/* 19 */     return this.hasElytra;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kelly\Desktop\anycapes-1.0.1.jar!\me\pepperbell\anycapes\cape\CapeTexture.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */