/*    */ package me.pepperbell.anycapes.util;
/*    */ 
/*    */ import net.minecraft.class_1011;
/*    */ 
/*    */ public class ImageUtil {
/*    */   public static class_1011 resizeCanvas(class_1011 nativeImage, int width, int height) {
/*  7 */     int minWidth = Math.min(nativeImage.method_4307(), width);
/*  8 */     int minHeight = Math.min(nativeImage.method_4323(), height);
/*  9 */     class_1011 resized = new class_1011(width, height, true);
/* 10 */     for (int x = 0; x < minWidth; x++) {
/* 11 */       for (int y = 0; y < minHeight; y++) {
/* 12 */         resized.method_4305(x, y, nativeImage.method_4315(x, y));
/*    */       }
/*    */     } 
/* 15 */     nativeImage.close();
/* 16 */     return resized;
/*    */   }
/*    */   
/*    */   public static class_1011 cropAndResizeCanvas(class_1011 nativeImage, int width, int height, int left, int top, int right, int bottom) {
/* 20 */     int minWidth = Math.min(nativeImage.method_4307() - left - right, width);
/* 21 */     int minHeight = Math.min(nativeImage.method_4323() - top - bottom, height);
/* 22 */     class_1011 resized = new class_1011(width, height, true);
/* 23 */     for (int x = 0; x < minWidth; x++) {
/* 24 */       for (int y = 0; y < minHeight; y++) {
/* 25 */         resized.method_4305(x, y, nativeImage.method_4315(x + left, y + top));
/*    */       }
/*    */     } 
/* 28 */     nativeImage.close();
/* 29 */     return resized;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kelly\Desktop\anycapes-1.0.1.jar!\me\pepperbell\anycape\\util\ImageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */