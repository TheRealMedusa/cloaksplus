package me.pepperbell.anycapes.mixinterface;

import java.io.File;
import me.pepperbell.anycapes.cape.AbstractCapeProvider;
import net.minecraft.class_1060;

public interface PlayerSkinProviderAccess {
  AbstractCapeProvider getCapeProvider();
  
  void setCapeProvider(AbstractCapeProvider paramAbstractCapeProvider);
  
  class_1060 getTextureManager();
  
  File getSkinCacheDir();
}


/* Location:              C:\Users\Kelly\Desktop\anycapes-1.0.1.jar!\me\pepperbell\anycapes\mixinterface\PlayerSkinProviderAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */