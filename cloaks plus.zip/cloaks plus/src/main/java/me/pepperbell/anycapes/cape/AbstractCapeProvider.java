/*     */ package me.pepperbell.anycapes.cape;
/*     */ 
/*     */ import com.google.common.hash.Hashing;
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.authlib.minecraft.MinecraftProfileTexture;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.Proxy;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.Executor;
/*     */ import me.pepperbell.anycapes.mixin.ElytraFeatureRendererAccessor;
/*     */ import net.minecraft.class_1011;
/*     */ import net.minecraft.class_1044;
/*     */ import net.minecraft.class_1060;
/*     */ import net.minecraft.class_1071;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractCapeProvider
/*     */ {
/*  27 */   private static final class_2960 DEFAULT_ELYTRA = ElytraFeatureRendererAccessor.getElytraTexture();
/*     */   
/*     */   private File skinCacheDir;
/*     */   private class_1060 textureManager;
/*     */   private Executor executor;
/*     */   private Proxy proxy;
/*     */   
/*     */   public AbstractCapeProvider(File skinCacheDir, class_1060 textureManager, Executor executor, Proxy proxy) {
/*  35 */     this.skinCacheDir = skinCacheDir;
/*  36 */     this.textureManager = textureManager;
/*  37 */     this.executor = executor;
/*  38 */     this.proxy = proxy;
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadCape(GameProfile gameProfile, MinecraftProfileTexture mojangCape, class_1071.class_1072 callback) {
/*  43 */     String hash = Hashing.sha1().hashUnencodedChars("cape-" + gameProfile.getId().toString()).toString();
/*  44 */     class_2960 identifier = new class_2960("skins/" + hash);
/*  45 */     class_1044 texture = this.textureManager.method_4619(identifier);
/*  46 */     if (texture != null) {
/*  47 */       if (callback != null) {
/*  48 */         if (texture instanceof CapeTexture && 
/*  49 */           !((CapeTexture)texture).hasElytra()) {
/*  50 */           callback.onSkinTextureAvailable(MinecraftProfileTexture.Type.ELYTRA, DEFAULT_ELYTRA, null);
/*     */         }
/*     */         
/*  53 */         callback.onSkinTextureAvailable(MinecraftProfileTexture.Type.CAPE, identifier, null);
/*     */       } 
/*     */     } else {
/*  56 */       File cacheFile = null;
/*  57 */       if (useCaching()) {
/*  58 */         cacheFile = new File(new File(this.skinCacheDir, (hash.length() > 2) ? hash.substring(0, 2) : "xx"), hash);
/*     */       }
/*  60 */       getCape(gameProfile, (mojangCape == null) ? null : mojangCape.getUrl(), cacheFile, (nativeImage, url) -> class_310.method_1551().execute(()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getCape(GameProfile gameProfile, String mojangCapeUrl, File cacheFile, ImageDownloadCallback callback) {
/*  80 */     if (cacheFile != null && cacheFile.isFile()) {
/*  81 */       class_1011 nativeImage = null;
/*     */       try {
/*  83 */         FileInputStream fileInputStream = new FileInputStream(cacheFile);
/*  84 */         nativeImage = class_1011.method_4309(fileInputStream);
/*  85 */       } catch (Exception exception) {
/*  86 */         cacheFile.delete();
/*     */       } 
/*  88 */       if (nativeImage != null) {
/*  89 */         callback.onSuccess(nativeImage, null);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*  94 */     downloadCape(gameProfile, mojangCapeUrl, cacheFile, callback);
/*     */   }
/*     */   
/*     */   public void downloadCape(GameProfile gameProfile, String mojangCapeUrl, File cacheFile, ImageDownloadCallback callback) {
/*  98 */     CompletableFuture.runAsync(() -> downloadCape(getCapeUrls(), 0, gameProfile, mojangCapeUrl, cacheFile, callback), this.executor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void downloadCape(List<String> urls, int index, GameProfile gameProfile, String mojangCapeUrl, File cacheFile, ImageDownloadCallback callback) {
/* 104 */     if (index >= urls.size()) {
/*     */       return;
/*     */     }
/* 107 */     URL url = formatUrl(urls.get(index), gameProfile, mojangCapeUrl);
/* 108 */     if (url == null) {
/* 109 */       downloadCape(urls, index + 1, gameProfile, mojangCapeUrl, cacheFile, callback);
/*     */       return;
/*     */     } 
/* 112 */     CompletableFuture<class_1011> future = downloadImage(url, cacheFile);
/* 113 */     future.whenCompleteAsync((nativeImage, throwable) -> { if (nativeImage != null && throwable == null) { callback.onSuccess(nativeImage, url); } else { downloadCape(urls, index + 1, gameProfile, mojangCapeUrl, cacheFile, callback); }  }this.executor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompletableFuture<class_1011> downloadImage(URL url, File cacheFile) {
/* 123 */     return CompletableFuture.supplyAsync(() -> {
/*     */           HttpURLConnection httpURLConnection = null;
/*     */           class_1011 nativeImage = null;
/*     */           try {
/*     */             httpURLConnection = (HttpURLConnection)url.openConnection(this.proxy);
/*     */             httpURLConnection.connect();
/*     */             if (httpURLConnection.getResponseCode() / 100 == 2) {
/*     */               InputStream inputStream = httpURLConnection.getInputStream();
/*     */               nativeImage = class_1011.method_4309(inputStream);
/*     */               if (cacheFile != null) {
/*     */                 nativeImage.method_4325(cacheFile);
/*     */               }
/*     */             } 
/* 136 */           } catch (Exception exception) {
/*     */             throw new RuntimeException(exception);
/*     */           } finally {
/*     */             if (httpURLConnection != null)
/*     */               httpURLConnection.disconnect(); 
/*     */           } 
/*     */           return nativeImage;
/*     */         }this.executor);
/*     */   }
/*     */   
/*     */   public abstract List<String> getCapeUrls();
/*     */   
/*     */   public abstract boolean useCaching();
/*     */   
/*     */   public abstract URL formatUrl(String paramString1, GameProfile paramGameProfile, String paramString2);
/*     */   
/*     */   public abstract CapeTransformResult transformCapeImage(class_1011 paramclass_1011);
/*     */ }


/* Location:              C:\Users\Kelly\Desktop\anycapes-1.0.1.jar!\me\pepperbell\anycapes\cape\AbstractCapeProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */