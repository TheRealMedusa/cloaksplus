/*    */ package me.pepperbell.anycapes.mixin;
/*    */ 
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_979;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.gen.Accessor;
/*    */ 
/*    */ @Mixin({class_979.class})
/*    */ public interface ElytraFeatureRendererAccessor
/*    */ {
/*    */   @Accessor("SKIN")
/*    */   static class_2960 getElytraTexture() {
/* 13 */     throw new AssertionError();
/*    */   }
/*    */ }


/* Location:              C:\Users\Kelly\Desktop\anycapes-1.0.1.jar!\me\pepperbell\anycapes\mixin\ElytraFeatureRendererAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */