package me.pepperbell.anycapes.cape;

import java.net.URL;
import net.minecraft.class_1011;

public interface ImageDownloadCallback {
  void onSuccess(class_1011 paramclass_1011, URL paramURL);
}


/* Location:              C:\Users\Kelly\Desktop\anycapes-1.0.1.jar!\me\pepperbell\anycapes\cape\ImageDownloadCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */