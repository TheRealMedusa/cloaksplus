/*    */ package me.pepperbell.anycapes.util;
/*    */ 
/*    */ import net.minecraft.class_2477;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_2585;
/*    */ 
/*    */ public class ParsingUtil {
/*    */   public static class_2561[] parseNewlines(String translationKey) {
/*  9 */     if (!class_2477.method_10517().method_4678(translationKey)) {
/* 10 */       return null;
/*    */     }
/* 12 */     String[] strings = class_2477.method_10517().method_4679(translationKey).split("\n|\\\\n");
/* 13 */     class_2561[] texts = new class_2561[strings.length];
/* 14 */     for (int i = 0; i < strings.length; i++) {
/* 15 */       texts[i] = (class_2561)new class_2585(strings[i]);
/*    */     }
/* 17 */     return texts;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kelly\Desktop\anycapes-1.0.1.jar!\me\pepperbell\anycape\\util\ParsingUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */