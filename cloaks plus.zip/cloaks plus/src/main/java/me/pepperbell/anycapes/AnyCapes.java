/*    */ package me.pepperbell.anycapes;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.nio.file.Path;
/*    */ import me.pepperbell.anycapes.cape.AbstractCapeProvider;
/*    */ import me.pepperbell.anycapes.cape.CapeProvider;
/*    */ import me.pepperbell.anycapes.data.Config;
/*    */ import me.pepperbell.anycapes.mixinterface.PlayerSkinProviderAccess;
/*    */ import net.fabricmc.api.ClientModInitializer;
/*    */ import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
/*    */ import net.fabricmc.loader.api.FabricLoader;
/*    */ import net.minecraft.class_156;
/*    */ import net.minecraft.class_310;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class AnyCapes implements ClientModInitializer {
/* 18 */   public static final Logger LOGGER = LogManager.getLogger();
/*    */   
/*    */   private static Config config;
/*    */   
/*    */   public static Config getConfig() {
/* 23 */     if (config == null) {
/* 24 */       loadConfig();
/*    */     }
/* 26 */     return config;
/*    */   }
/*    */   
/*    */   private static void loadConfig() {
/* 30 */     Path configPath = FabricLoader.getInstance().getConfigDir();
/* 31 */     File configFile = new File(configPath.toFile(), "anycapes.json");
/* 32 */     config = new Config(configFile);
/* 33 */     config.load();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onInitializeClient() {
/* 38 */     ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
/*    */           PlayerSkinProviderAccess skinProviderAccess = (PlayerSkinProviderAccess)client.method_1582();
/*    */           skinProviderAccess.setCapeProvider((AbstractCapeProvider)new CapeProvider(skinProviderAccess.getSkinCacheDir(), skinProviderAccess.getTextureManager(), class_156.method_18349(), client.method_1487()));
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\Kelly\Desktop\anycapes-1.0.1.jar!\me\pepperbell\anycapes\AnyCapes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */