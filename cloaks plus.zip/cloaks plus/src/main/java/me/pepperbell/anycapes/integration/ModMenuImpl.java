/*    */ package me.pepperbell.anycapes.integration;
/*    */ import io.github.prospector.modmenu.api.ConfigScreenFactory;
/*    */ import io.github.prospector.modmenu.api.ModMenuApi;
/*    */ import me.pepperbell.anycapes.AnyCapes;
/*    */ import net.fabricmc.loader.api.FabricLoader;
/*    */ import net.minecraft.class_437;
/*    */ 
/*    */ public class ModMenuImpl implements ModMenuApi {
/*    */   public ConfigScreenFactory<?> getModConfigScreenFactory() {
/* 10 */     if (FabricLoader.getInstance().isModLoaded("cloth-config2")) {
/* 11 */       return new ClothConfigFactory(AnyCapes.getConfig());
/*    */     }
/* 13 */     return screen -> null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kelly\Desktop\anycapes-1.0.1.jar!\me\pepperbell\anycapes\integration\ModMenuImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */