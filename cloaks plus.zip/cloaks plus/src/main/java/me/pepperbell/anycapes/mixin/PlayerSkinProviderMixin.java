/*    */ package me.pepperbell.anycapes.mixin;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import com.mojang.authlib.minecraft.MinecraftProfileTexture;
/*    */ import com.mojang.blaze3d.systems.RenderSystem;
/*    */ import java.io.File;
/*    */ import java.util.Map;
/*    */ import me.pepperbell.anycapes.cape.AbstractCapeProvider;
/*    */ import me.pepperbell.anycapes.mixinterface.PlayerSkinProviderAccess;
/*    */ import net.minecraft.class_1060;
/*    */ import net.minecraft.class_1071;
/*    */ import net.minecraft.class_310;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.gen.Accessor;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_1071.class})
/*    */ public abstract class PlayerSkinProviderMixin
/*    */   implements PlayerSkinProviderAccess
/*    */ {
/*    */   @Unique
/*    */   private AbstractCapeProvider capeProvider;
/*    */   
/*    */   public AbstractCapeProvider getCapeProvider() {
/* 32 */     return this.capeProvider;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCapeProvider(AbstractCapeProvider capeProvider) {
/* 37 */     this.capeProvider = capeProvider;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Accessor("textureManager")
/*    */   public abstract class_1060 getTextureManager();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Accessor("skinCacheDir")
/*    */   public abstract File getSkinCacheDir();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;execute(Ljava/lang/Runnable;)V")}, method = {"method_4653(Lcom/mojang/authlib/GameProfile;ZLnet/minecraft/client/texture/PlayerSkinProvider$SkinTextureAvailableCallback;)V"}, locals = LocalCapture.CAPTURE_FAILHARD)
/*    */   public void onLoadSkinRunnable(GameProfile profile, boolean requireSecure, class_1071.class_1072 callback, CallbackInfo ci, Map<MinecraftProfileTexture.Type, MinecraftProfileTexture> map) {
/* 57 */     class_310.method_1551().execute(() -> RenderSystem.recordRenderCall(()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Kelly\Desktop\anycapes-1.0.1.jar!\me\pepperbell\anycapes\mixin\PlayerSkinProviderMixin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */