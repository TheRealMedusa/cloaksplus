/*    */ package me.pepperbell.anycapes.cape;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import java.io.File;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.Proxy;
/*    */ import java.net.URL;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.Executor;
/*    */ import me.pepperbell.anycapes.AnyCapes;
/*    */ import me.pepperbell.anycapes.util.ImageUtil;
/*    */ import net.minecraft.class_1011;
/*    */ import net.minecraft.class_1060;
/*    */ 
/*    */ public class CapeProvider
/*    */   extends AbstractCapeProvider
/*    */ {
/*    */   public CapeProvider(File skinCacheDir, class_1060 textureManager, Executor executor, Proxy proxy) {
/* 19 */     super(skinCacheDir, textureManager, executor, proxy);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getCapeUrls() {
/* 24 */     return (AnyCapes.getConfig().getOptions()).capeUrls;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean useCaching() {
/* 29 */     return (AnyCapes.getConfig().getOptions()).useCaching;
/*    */   }
/*    */ 
/*    */   
/*    */   public URL formatUrl(String urlStr, GameProfile gameProfile, String mojangCapeUrl) {
/* 34 */     if (urlStr.contains("{mojang}")) {
/* 35 */       if (mojangCapeUrl == null) {
/* 36 */         return null;
/*    */       }
/* 38 */       urlStr = urlStr.replace("{mojang}", mojangCapeUrl);
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 44 */     urlStr = urlStr.replace("{username}", gameProfile.getName()).replace("{uuid}", gameProfile.getId().toString().replace("-", "")).replace("{uuid-dash}", gameProfile.getId().toString());
/*    */     
/* 46 */     URL url = null;
/*    */     try {
/* 48 */       url = new URL(urlStr);
/* 49 */     } catch (MalformedURLException e) {
/* 50 */       AnyCapes.LOGGER.warn("Invalid URL: " + urlStr);
/*    */     } 
/* 52 */     return url;
/*    */   }
/*    */ 
/*    */   
/*    */   public CapeTransformResult transformCapeImage(class_1011 capeImage) {
/*    */     class_1011 transformed;
/* 58 */     boolean hasElytra = true;
/*    */     
/* 60 */     if (capeImage.method_4307() % 46 == 0 && capeImage.method_4323() % 22 == 0) {
/* 61 */       int scale = capeImage.method_4307() / 46;
/* 62 */       transformed = ImageUtil.resizeCanvas(capeImage, scale * 64, scale * 32);
/* 63 */     } else if (capeImage.method_4307() % 22 == 0 && capeImage.method_4323() % 17 == 0) {
/* 64 */       int scale = capeImage.method_4307() / 22;
/* 65 */       transformed = ImageUtil.resizeCanvas(capeImage, scale * 64, scale * 32);
/* 66 */       hasElytra = false;
/* 67 */     } else if (capeImage.method_4307() % 355 == 0 && capeImage.method_4323() % 275 == 0) {
/* 68 */       int scale = capeImage.method_4307() / 355;
/* 69 */       transformed = ImageUtil.cropAndResizeCanvas(capeImage, scale * 1024, scale * 512, scale * 2, scale * 2, scale, scale);
/* 70 */       hasElytra = false;
/* 71 */     } else if (capeImage.method_4307() % 352 == 0 && capeImage.method_4323() % 275 == 0) {
/* 72 */       int scale = capeImage.method_4307() / 352;
/* 73 */       transformed = ImageUtil.cropAndResizeCanvas(capeImage, scale * 1024, scale * 512, 0, scale * 2, 0, scale);
/* 74 */       hasElytra = false;
/* 75 */     } else if (capeImage.method_4307() % 355 == 0 && capeImage.method_4323() % 272 == 0) {
/* 76 */       int scale = capeImage.method_4307() / 355;
/* 77 */       transformed = ImageUtil.cropAndResizeCanvas(capeImage, scale * 1024, scale * 512, scale * 2, 0, scale, 0);
/* 78 */       hasElytra = false;
/*    */     } else {
/* 80 */       transformed = capeImage;
/*    */     } 
/*    */     
/* 83 */     return new CapeTransformResult(transformed, hasElytra);
/*    */   }
/*    */ }


/* Location:              C:\Users\Kelly\Desktop\anycapes-1.0.1.jar!\me\pepperbell\anycapes\cape\CapeProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */