/*    */ package me.pepperbell.anycapes.cape;
/*    */ 
/*    */ import net.minecraft.class_1011;
/*    */ 
/*    */ public class CapeTransformResult {
/*    */   public class_1011 transformedImage;
/*    */   public boolean hasElytra;
/*    */   
/*    */   public CapeTransformResult(class_1011 transformedImage, boolean hasElytra) {
/* 10 */     this.transformedImage = transformedImage;
/* 11 */     this.hasElytra = hasElytra;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kelly\Desktop\anycapes-1.0.1.jar!\me\pepperbell\anycapes\cape\CapeTransformResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */