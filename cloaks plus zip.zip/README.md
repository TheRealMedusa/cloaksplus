# AnyCapes
 
A Fabric mod that retrieves and renders capes from any cape API.

CurseForge project page: https://www.curseforge.com/minecraft/mc-mods/anycapes
